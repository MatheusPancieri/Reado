namespace Reado.Domain.Request.Books;

public class DeleteBookRequest : Request
{
    public long Id { get; set; }
}
