namespace Reado.Domain.Request
{
    public class Request
    {
        public string UserId { get; set; } = string.Empty;
    }
}