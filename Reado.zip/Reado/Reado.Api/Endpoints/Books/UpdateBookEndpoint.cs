using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Reado.Api.Endpoints.Books;

public class UpdateBookEndpoint
{
    
}
